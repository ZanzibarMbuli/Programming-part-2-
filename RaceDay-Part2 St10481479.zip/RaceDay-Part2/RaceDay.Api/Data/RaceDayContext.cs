using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;
namespace RaceDay.Api.Data;
public class RaceDayContext(DbContextOptions<RaceDayContext> options) : DbContext(options)
{
 public DbSet<Role> Roles => Set<Role>(); public DbSet<User> Users => Set<User>(); public DbSet<Organiser> Organisers => Set<Organiser>(); public DbSet<Participant> Participants => Set<Participant>(); public DbSet<Event> Events => Set<Event>(); public DbSet<Category> Categories => Set<Category>(); public DbSet<EventEnrolment> EventEnrolments => Set<EventEnrolment>(); public DbSet<Result> Results => Set<Result>();
 protected override void OnModelCreating(ModelBuilder b)
 {
  // Explicit keys are important because EventEnrolment uses EnrolmentID,
  // which EF Core does not infer as the key for an EventEnrolment entity.
  b.Entity<Role>().ToTable("Roles").HasKey(x => x.RoleID);
  b.Entity<Role>().HasIndex(x => x.RoleName).IsUnique();

  b.Entity<User>().ToTable("Users").HasKey(x => x.UserID);
  b.Entity<User>().HasIndex(x => x.Email).IsUnique();
  b.Entity<User>().Property(x => x.Email).HasMaxLength(120);
  b.Entity<User>().Property(x => x.PasswordHash).HasMaxLength(255);
  b.Entity<User>().HasOne(x => x.Role).WithMany(x => x.Users).HasForeignKey(x => x.RoleID);

  b.Entity<Organiser>().ToTable("Organisers").HasKey(x => x.OrganiserID);
  b.Entity<Organiser>().HasIndex(x => x.UserID).IsUnique();
  b.Entity<Organiser>().HasOne(x => x.User).WithOne(x => x.Organiser).HasForeignKey<Organiser>(x => x.UserID);

  b.Entity<Participant>().ToTable("Participants").HasKey(x => x.ParticipantID);
  b.Entity<Participant>().HasIndex(x => x.UserID).IsUnique();
  b.Entity<Participant>().HasOne(x => x.User).WithOne(x => x.Participant).HasForeignKey<Participant>(x => x.UserID);

  b.Entity<Event>().ToTable("Events").HasKey(x => x.EventID);
  b.Entity<Event>().Property(x => x.EntryFee).HasPrecision(10, 2);
  b.Entity<Event>().HasOne(x => x.Organiser).WithMany(x => x.Events).HasForeignKey(x => x.OrganiserID);

  b.Entity<Category>().ToTable("Categories").HasKey(x => x.CategoryID);
  b.Entity<Category>().HasIndex(x => new { x.EventID, x.CategoryName }).IsUnique();
  b.Entity<Category>().Property(x => x.DistanceKM).HasPrecision(6, 2);
  b.Entity<Category>().HasOne(x => x.Event).WithMany(x => x.Categories).HasForeignKey(x => x.EventID);

  b.Entity<EventEnrolment>().ToTable("EventEnrolments").HasKey(x => x.EnrolmentID);
  b.Entity<EventEnrolment>().HasIndex(x => new { x.EventID, x.ParticipantID }).IsUnique();
  b.Entity<EventEnrolment>().HasIndex(x => new { x.EventID, x.RaceNumber }).IsUnique();
  b.Entity<EventEnrolment>().HasOne(x => x.Event).WithMany(x => x.Enrolments).HasForeignKey(x => x.EventID);
  b.Entity<EventEnrolment>().HasOne(x => x.Category).WithMany(x => x.Enrolments).HasForeignKey(x => x.CategoryID);
  b.Entity<EventEnrolment>().HasOne(x => x.Participant).WithMany(x => x.Enrolments).HasForeignKey(x => x.ParticipantID);

  b.Entity<Result>().ToTable("Results").HasKey(x => x.ResultID);
  b.Entity<Result>().HasIndex(x => x.EnrolmentID).IsUnique();
  b.Entity<Result>().HasOne(x => x.Enrolment).WithOne(x => x.Result).HasForeignKey<Result>(x => x.EnrolmentID);
 }

}
