namespace RaceDay.Api.Models;

/// <summary>Centralised request validation shared by API handlers and unit tests.</summary>
public static class ValidationRules
{
    public static bool IsValidEmail(string? email) =>
        !string.IsNullOrWhiteSpace(email) && email.Length <= 120 &&
        System.Net.Mail.MailAddress.TryCreate(email.Trim(), out var parsed) &&
        string.Equals(parsed.Address, email.Trim(), StringComparison.OrdinalIgnoreCase);

    public static bool IsStrongEnoughPassword(string? password) =>
        !string.IsNullOrWhiteSpace(password) && password.Length >= 8 && password.Length <= 128 &&
        password.Any(char.IsLetter) && password.Any(char.IsDigit);

    public static bool IsValidDateOfBirth(string? value, out DateOnly dateOfBirth)
    {
        dateOfBirth = default;
        return DateOnly.TryParseExact(value, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out dateOfBirth) &&
            dateOfBirth <= DateOnly.FromDateTime(DateTime.UtcNow) &&
            dateOfBirth >= DateOnly.FromDateTime(DateTime.UtcNow.AddYears(-120));
    }

    public static bool IsValidEvent(string? name, string? venue, string? city, decimal fee, int capacity, string? status) =>
        !string.IsNullOrWhiteSpace(name) && name.Trim().Length <= 150 &&
        !string.IsNullOrWhiteSpace(venue) && venue.Trim().Length <= 150 &&
        !string.IsNullOrWhiteSpace(city) && city.Trim().Length <= 100 &&
        fee >= 0 && fee <= 1000000 && capacity is >= 1 and <= 100000 &&
        (string.IsNullOrWhiteSpace(status) || new[] { "Open", "Closed", "Completed", "Cancelled" }.Contains(status, StringComparer.OrdinalIgnoreCase));

    public static bool IsValidCategory(string? name, int? minimumAge, int? maximumAge, string? gender, decimal distanceKm) =>
        !string.IsNullOrWhiteSpace(name) && name.Trim().Length <= 100 &&
        (!minimumAge.HasValue || minimumAge.Value is >= 0 and <= 120) &&
        (!maximumAge.HasValue || maximumAge.Value is >= 0 and <= 120) &&
        (!minimumAge.HasValue || !maximumAge.HasValue || maximumAge.Value >= minimumAge.Value) &&
        (string.IsNullOrWhiteSpace(gender) || new[] { "Open", "Male", "Female", "Mixed" }.Contains(gender, StringComparer.OrdinalIgnoreCase)) &&
        distanceKm > 0 && distanceKm <= 500;

    public static bool IsValidResult(int? finishPosition, string? status) =>
        (!finishPosition.HasValue || finishPosition.Value > 0) &&
        (string.IsNullOrWhiteSpace(status) || new[] { "Finished", "DidNotFinish", "Disqualified", "DidNotStart" }.Contains(status, StringComparer.OrdinalIgnoreCase));
}
