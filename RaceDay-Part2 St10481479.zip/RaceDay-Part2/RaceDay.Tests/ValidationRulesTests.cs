using RaceDay.Api.Models;
using Xunit;

namespace RaceDay.Tests;

public class ValidationRulesTests
{
    [Theory]
    [InlineData("runner@example.com", true)]
    [InlineData("not-an-email", false)]
    [InlineData("", false)]
    [InlineData("runner@example.com" + "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", false)]
    public void EmailValidationRejectsMalformedOrOversizedValues(string email, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsValidEmail(email));

    [Theory]
    [InlineData("RaceDay123", true)]
    [InlineData("password", false)]
    [InlineData("12345678", false)]
    [InlineData("short1", false)]
    [InlineData("", false)]
    public void PasswordMustHaveMinimumLengthLettersAndDigits(string password, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsStrongEnoughPassword(password));

    [Theory]
    [InlineData("2000-01-31", true)]
    [InlineData("31/01/2000", false)]
    [InlineData("not-a-date", false)]
    [InlineData("2999-01-01", false)]
    public void DateOfBirthRequiresIsoFormatAndPlausiblePastDate(string date, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsValidDateOfBirth(date, out _));

    [Theory]
    [InlineData("City Run", "Sports Ground", "Johannesburg", 100, 500, "Open", true)]
    [InlineData("", "Sports Ground", "Johannesburg", 100, 500, "Open", false)]
    [InlineData("City Run", "Sports Ground", "Johannesburg", -1, 500, "Open", false)]
    [InlineData("City Run", "Sports Ground", "Johannesburg", 100, 0, "Open", false)]
    [InlineData("City Run", "Sports Ground", "Johannesburg", 100, 500, "Unknown", false)]
    public void EventValidationChecksRequiredFieldsAndBusinessRules(string name, string venue, string city, decimal fee, int capacity, string status, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsValidEvent(name, venue, city, fee, capacity, status));

    [Theory]
    [InlineData("5 km", 10, 50, "Open", 5, true)]
    [InlineData("5 km", 50, 10, "Open", 5, false)]
    [InlineData("5 km", -1, 10, "Open", 5, false)]
    [InlineData("5 km", 10, 50, "Invalid", 5, false)]
    [InlineData("5 km", 10, 50, "Open", 0, false)]
    public void CategoryValidationChecksAgeGenderAndDistance(string name, int min, int max, string gender, decimal distance, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsValidCategory(name, min, max, gender, distance));

    [Theory]
    [InlineData(1, "Finished", true)]
    [InlineData(0, "Finished", false)]
    [InlineData(-1, "Finished", false)]
    [InlineData(null, "DidNotFinish", true)]
    [InlineData(2, "Unknown", false)]
    public void ResultValidationChecksPositionAndStatus(int? position, string status, bool expected) =>
        Assert.Equal(expected, ValidationRules.IsValidResult(position, status));

    [Fact]
    public void NewEventDefaultsToOpenStatus() => Assert.Equal("Open", new RaceDay.Api.Models.Event().Status);

    [Fact]
    public void NewEnrolmentDefaultsToConfirmed() => Assert.Equal("Confirmed", new EventEnrolment().EnrolmentStatus);

    [Fact]
    public void ResultDefaultsToFinished() => Assert.Equal("Finished", new Result().ResultStatus);

    [Theory]
    [InlineData("Organiser")]
    [InlineData("Participant")]
    public void RoleNamesAreRecognised(string roleName) => Assert.Contains(roleName, new[] { "Organiser", "Participant" });
}
