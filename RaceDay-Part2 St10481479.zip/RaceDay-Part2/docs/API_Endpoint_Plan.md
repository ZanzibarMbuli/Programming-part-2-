# RaceDay API Endpoint Plan
## Part 1 – System Planning and Database

### API conventions
- Base route: `/api`
- JSON is used for request and response bodies.
- Authentication: bearer token/JWT is assumed for protected endpoints.
- Roles: **Organiser** and **Participant**.
- `GET` is used for retrieval, `POST` for creation, `PUT` for updates and `DELETE` for removal.
- The endpoint plan is deliberately aligned with the RaceDay database and the planned Part 2 REST API.

| # | HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|---|
| 1 | POST | `/api/auth/register` | Registers a new RaceDay user and participant account. | None | `{firstName,lastName,email,password,phone,dateOfBirth}` | **201 Created**; user/profile created. **400** validation error. **409** email exists. |
| 2 | POST | `/api/auth/login` | Authenticates a registered user and returns an access token and role. | None | `{email,password}` | **200 OK** with token and user details. **401** invalid credentials. |
| 3 | GET | `/api/profile` | Returns the logged-in user's profile and role-specific information. | Any logged-in user | None | **200 OK**. **401** unauthenticated. |
| 4 | PUT | `/api/profile` | Updates the logged-in user's profile information. | Any logged-in user | `{firstName,lastName,phone}` | **200 OK**. **400** validation error. **401** unauthenticated. |
| 5 | GET | `/api/events` | Returns available events with basic event information. | None | Optional query filters | **200 OK** list of events. |
| 6 | GET | `/api/events/{id}` | Returns one event including organiser and event details. | None | None | **200 OK**. **404** event not found. |
| 7 | POST | `/api/events` | Creates a new race event. | Organiser | `{eventName,eventDescription,eventDate,startTime,venue,city,entryFee,capacity,status}` | **201 Created**. **400** invalid data. **401/403** access failure. |
| 8 | PUT | `/api/events/{id}` | Updates an event owned by the logged-in organiser. | Organiser | Event fields to update | **200 OK**. **404** not found. **403** not owner. |
| 9 | DELETE | `/api/events/{id}` | Deletes/removes an event that has not been completed. | Organiser | None | **204 No Content**. **404** not found. **409** event cannot be removed. |
| 10 | GET | `/api/events/{eventId}/categories` | Lists all categories belonging to an event. | None | None | **200 OK** list. **404** event not found. |
| 11 | POST | `/api/events/{eventId}/categories` | Creates a category for an event. | Organiser | `{categoryName,minimumAge,maximumAge,gender,distanceKM}` | **201 Created**. **400** validation. **409** duplicate category. |
| 12 | PUT | `/api/events/{eventId}/categories/{categoryId}` | Updates an event category. | Organiser | Category fields | **200 OK**. **404** not found. **403** not owner. |
| 13 | DELETE | `/api/events/{eventId}/categories/{categoryId}` | Removes a category if no enrolments depend on it. | Organiser | None | **204 No Content**. **409** category in use. |
| 14 | GET | `/api/events/{eventId}/enrolments` | Returns enrolments for an event for organiser management. | Organiser | Optional status filter | **200 OK** list. **403** forbidden. |
| 15 | POST | `/api/events/{eventId}/enrolments` | Enrols the logged-in participant in a selected event category. | Participant | `{categoryId}` | **201 Created** with enrolment/race number. **409** already enrolled. **400** invalid category/event. |
| 16 | GET | `/api/enrolments/{id}` | Returns one enrolment and its event/category details. | Participant owner / Organiser | None | **200 OK**. **403/404** where applicable. |
| 17 | DELETE | `/api/enrolments/{id}` | Cancels a participant's enrolment before the event closes. | Participant owner | None | **204 No Content**. **409** cancellation not allowed. |
| 18 | GET | `/api/participants/{participantId}/enrolments` | Lists a participant's event enrolments. | Participant owner / Organiser | None | **200 OK** list. **403/404** where applicable. |
| 19 | GET | `/api/events/{eventId}/results` | Returns published results for an event, ordered by finishing position. | None | Optional category filter | **200 OK** results. **404** event not found. |
| 20 | GET | `/api/results/{id}` | Returns a single participant result. | None | None | **200 OK**. **404** result not found. |
| 21 | POST | `/api/events/{eventId}/results` | Records a result for an enrolled participant. | Organiser | `{enrolmentId,finishTime,finishPosition,resultStatus}` | **201 Created**. **400** invalid result. **409** result already exists. |
| 22 | PUT | `/api/results/{id}` | Corrects or updates a recorded result. | Organiser | Result fields | **200 OK**. **404** result not found. |
| 23 | GET | `/api/organisers/{organiserId}/events` | Returns events managed by a specific organiser. | None | None | **200 OK** list. **404** organiser not found. |
| 24 | GET | `/api/categories/{categoryId}` | Returns one category with its event information. | None | None | **200 OK**. **404** category not found. |

## Role rules

### Organiser
An organiser can:
- Register/login.
- View and update their profile.
- Create, update and manage their own events.
- Create and manage categories for their events.
- View enrolments for their events.
- Record and update results.

### Participant
A participant can:
- Register/login.
- View and update their own profile.
- Browse events and categories.
- Enrol in an available category.
- View their own enrolments.
- Cancel an eligible enrolment.
- View published results.

### Public user
A visitor who is not logged in can:
- Browse events.
- View event details.
- View categories.
- View published results.
- Register and login.

## Database-to-API consistency

The planned API maps directly to the database entities:

- `Roles` → authentication/authorisation.
- `Users` → account and profile.
- `Organisers` → organiser profile and ownership of events.
- `Participants` → participant profile.
- `Events` → race events.
- `Categories` → event-specific race categories.
- `EventEnrolments` → participant registrations.
- `Results` → finishing results.

This mapping should be maintained during Part 2 so that the implemented API closely matches the approved Part 1 plan.
