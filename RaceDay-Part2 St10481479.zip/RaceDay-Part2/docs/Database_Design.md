# RaceDay Database Design
## Part 1 – System Planning and Database

### 1. System purpose
RaceDay is an event-management system for road races, trail races and similar sporting events. The system supports two main roles: Organiser and Participant.

Organisers create and manage events, define event categories, view participant enrolments and record results. Participants create accounts, browse events, enrol in categories and view their results.

### 2. Entities
The database contains eight core entities:

1. **Roles** – defines the two application roles.
2. **Users** – stores authentication and common profile information.
3. **Organisers** – stores organiser-specific profile information.
4. **Participants** – stores participant-specific information.
5. **Events** – stores race event information and links each event to its organiser.
6. **Categories** – stores the categories offered by each event.
7. **EventEnrolments** – resolves the many-to-many relationship between participants and events and records category/race-number information.
8. **Results** – stores the final result associated with an enrolment.

### 3. Relationships and cardinalities

- One **Role** can be assigned to many **Users**; each User has one Role.
- One **User** can have zero or one **Organiser** profile.
- One **User** can have zero or one **Participant** profile.
- One **Organiser** can create many **Events**; each Event belongs to one Organiser.
- One **Event** has one or many **Categories**; each Category belongs to one Event.
- One **Participant** can have many **EventEnrolments**.
- One **Event** can have many **EventEnrolments**.
- Therefore, Participants and Events have a many-to-many relationship resolved by **EventEnrolments**.
- One **Category** can have many **EventEnrolments**.
- One **EventEnrolment** can have zero or one **Result**.
- Every foreign key is represented in the SQL script.

### 4. Keys
Primary keys:
- Roles.RoleID
- Users.UserID
- Organisers.OrganiserID
- Participants.ParticipantID
- Events.EventID
- Categories.CategoryID
- EventEnrolments.EnrolmentID
- Results.ResultID

Foreign keys:
- Users.RoleID → Roles.RoleID
- Organisers.UserID → Users.UserID
- Participants.UserID → Users.UserID
- Events.OrganiserID → Organisers.OrganiserID
- Categories.EventID → Events.EventID
- EventEnrolments.EventID → Events.EventID
- EventEnrolments.CategoryID → Categories.CategoryID
- EventEnrolments.ParticipantID → Participants.ParticipantID
- Results.EnrolmentID → EventEnrolments.EnrolmentID

### 5. Integrity and constraints
The database applies:
- Primary-key constraints.
- Foreign-key constraints.
- Unique email addresses.
- Unique role names.
- Unique event/category combinations.
- Unique participant enrolment per event.
- Unique race number within an event.
- Unique result per enrolment.
- NOT NULL constraints on required fields.
- CHECK constraints for event status, enrolment status, gender, age ranges, positive capacity, distance and race numbers.
- DEFAULT values for dates, statuses and entry fees.

These constraints protect referential integrity and reduce invalid data entering the system.

### 6. Sample data
The SQL script contains more than the minimum requested sample data:
- 2 roles.
- 2 organisers.
- 4 participants.
- 3 events.
- 8 categories distributed across all 3 events.
- 8 enrolments.
- 8 results.

### 7. Design rationale
The design separates common user information from role-specific information. The EventEnrolments table is used as an associative entity because one participant can participate in multiple events and each event can contain multiple participants. Categories are linked to Events so that the same category name can be reused across different events without making categories global. Results are linked to enrolments because a result only exists for a participant who entered a particular event.

### 8. Consistency with the API
The database entities are intentionally aligned with the endpoint plan. This means Part 2 can implement the API without introducing unrelated entities or unexplained database changes.
