/* ============================================================
   RaceDay Event Management System
   Part 1 - System Planning and Database
   SQL Server / SSMS
   ============================================================ */

IF DB_ID('RaceDayDB') IS NOT NULL
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END;
GO

CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO

/* =========================
   1. ROLES
   ========================= */
CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) NOT NULL,
    RoleName NVARCHAR(30) NOT NULL,
    CONSTRAINT PK_Roles PRIMARY KEY (RoleID),
    CONSTRAINT UQ_Roles_RoleName UNIQUE (RoleName),
    CONSTRAINT CK_Roles_RoleName CHECK (RoleName IN ('Organiser', 'Participant'))
);
GO

/* =========================
   2. USERS
   ========================= */
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) NOT NULL,
    RoleID INT NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(120) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Phone NVARCHAR(20) NULL,
    DateRegistered DATETIME2(0) NOT NULL
        CONSTRAINT DF_Users_DateRegistered DEFAULT SYSUTCDATETIME(),
    IsActive BIT NOT NULL
        CONSTRAINT DF_Users_IsActive DEFAULT 1,

    CONSTRAINT PK_Users PRIMARY KEY (UserID),
    CONSTRAINT UQ_Users_Email UNIQUE (Email),
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleID)
        REFERENCES Roles(RoleID),
    CONSTRAINT CK_Users_Email CHECK (Email LIKE '%_@_%._%')
);
GO

/* =========================
   3. ORGANISERS
   One organiser profile belongs to one user.
   ========================= */
CREATE TABLE Organisers (
    OrganiserID INT IDENTITY(1,1) NOT NULL,
    UserID INT NOT NULL,
    OrganisationName NVARCHAR(120) NOT NULL,
    ContactEmail NVARCHAR(120) NOT NULL,

    CONSTRAINT PK_Organisers PRIMARY KEY (OrganiserID),
    CONSTRAINT UQ_Organisers_UserID UNIQUE (UserID),
    CONSTRAINT FK_Organisers_Users FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
);
GO

/* =========================
   4. PARTICIPANTS
   One participant profile belongs to one user.
   ========================= */
CREATE TABLE Participants (
    ParticipantID INT IDENTITY(1,1) NOT NULL,
    UserID INT NOT NULL,
    DateOfBirth DATE NOT NULL,

    CONSTRAINT PK_Participants PRIMARY KEY (ParticipantID),
    CONSTRAINT UQ_Participants_UserID UNIQUE (UserID),
    CONSTRAINT FK_Participants_Users FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
);
GO

/* =========================
   5. EVENTS
   ========================= */
CREATE TABLE Events (
    EventID INT IDENTITY(1,1) NOT NULL,
    OrganiserID INT NOT NULL,
    EventName NVARCHAR(150) NOT NULL,
    EventDescription NVARCHAR(500) NULL,
    EventDate DATE NOT NULL,
    StartTime TIME(0) NOT NULL,
    Venue NVARCHAR(150) NOT NULL,
    City NVARCHAR(80) NOT NULL,
    EntryFee DECIMAL(10,2) NOT NULL
        CONSTRAINT DF_Events_EntryFee DEFAULT 0.00,
    Capacity INT NOT NULL,
    Status NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Events_Status DEFAULT 'Open',

    CONSTRAINT PK_Events PRIMARY KEY (EventID),
    CONSTRAINT FK_Events_Organisers FOREIGN KEY (OrganiserID)
        REFERENCES Organisers(OrganiserID),
    CONSTRAINT CK_Events_EntryFee CHECK (EntryFee >= 0),
    CONSTRAINT CK_Events_Capacity CHECK (Capacity > 0),
    CONSTRAINT CK_Events_Status CHECK (Status IN ('Draft','Open','Closed','Completed','Cancelled'))
);
GO

/* =========================
   6. CATEGORIES
   Each event has one or more categories.
   ========================= */
CREATE TABLE Categories (
    CategoryID INT IDENTITY(1,1) NOT NULL,
    EventID INT NOT NULL,
    CategoryName NVARCHAR(100) NOT NULL,
    MinimumAge INT NULL,
    MaximumAge INT NULL,
    Gender NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Categories_Gender DEFAULT 'Open',
    DistanceKM DECIMAL(6,2) NOT NULL,

    CONSTRAINT PK_Categories PRIMARY KEY (CategoryID),
    CONSTRAINT FK_Categories_Events FOREIGN KEY (EventID)
        REFERENCES Events(EventID),
    CONSTRAINT UQ_Categories_Event_Category UNIQUE (EventID, CategoryName),
    CONSTRAINT CK_Categories_MinAge CHECK (MinimumAge IS NULL OR MinimumAge >= 0),
    CONSTRAINT CK_Categories_MaxAge CHECK (MaximumAge IS NULL OR MaximumAge >= 0),
    CONSTRAINT CK_Categories_AgeRange CHECK (
        MaximumAge IS NULL OR MinimumAge IS NULL OR MaximumAge >= MinimumAge
    ),
    CONSTRAINT CK_Categories_Gender CHECK (Gender IN ('Open','Male','Female')),
    CONSTRAINT CK_Categories_Distance CHECK (DistanceKM > 0)
);
GO

/* =========================
   7. EVENT ENROLMENTS
   ========================= */
CREATE TABLE EventEnrolments (
    EnrolmentID INT IDENTITY(1,1) NOT NULL,
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    ParticipantID INT NOT NULL,
    EnrolmentDate DATETIME2(0) NOT NULL
        CONSTRAINT DF_EventEnrolments_Date DEFAULT SYSUTCDATETIME(),
    EnrolmentStatus NVARCHAR(20) NOT NULL
        CONSTRAINT DF_EventEnrolments_Status DEFAULT 'Confirmed',
    RaceNumber INT NULL,

    CONSTRAINT PK_EventEnrolments PRIMARY KEY (EnrolmentID),
    CONSTRAINT FK_EventEnrolments_Events FOREIGN KEY (EventID)
        REFERENCES Events(EventID),
    CONSTRAINT FK_EventEnrolments_Categories FOREIGN KEY (CategoryID)
        REFERENCES Categories(CategoryID),
    CONSTRAINT FK_EventEnrolments_Participants FOREIGN KEY (ParticipantID)
        REFERENCES Participants(ParticipantID),
    CONSTRAINT UQ_EventEnrolments_Event_Participant UNIQUE (EventID, ParticipantID),
    CONSTRAINT UQ_EventEnrolments_Event_RaceNumber UNIQUE (EventID, RaceNumber),
    CONSTRAINT CK_EventEnrolments_Status CHECK (
        EnrolmentStatus IN ('Pending','Confirmed','Cancelled')
    ),
    CONSTRAINT CK_EventEnrolments_RaceNumber CHECK (
        RaceNumber IS NULL OR RaceNumber > 0
    )
);
GO

/* =========================
   8. RESULTS
   One result belongs to one enrolment.
   ========================= */
CREATE TABLE Results (
    ResultID INT IDENTITY(1,1) NOT NULL,
    EnrolmentID INT NOT NULL,
    FinishTime TIME(3) NULL,
    FinishPosition INT NULL,
    ResultStatus NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Results_Status DEFAULT 'Finished',
    RecordedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_Results_RecordedAt DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_Results PRIMARY KEY (ResultID),
    CONSTRAINT UQ_Results_EnrolmentID UNIQUE (EnrolmentID),
    CONSTRAINT FK_Results_EventEnrolments FOREIGN KEY (EnrolmentID)
        REFERENCES EventEnrolments(EnrolmentID),
    CONSTRAINT CK_Results_Position CHECK (
        FinishPosition IS NULL OR FinishPosition > 0
    ),
    CONSTRAINT CK_Results_Status CHECK (
        ResultStatus IN ('Finished','DidNotFinish','Disqualified')
    )
);
GO

/* ============================================================
   SAMPLE DATA
   Requirements exceeded:
   - 2 roles
   - 2+ organisers
   - 3+ participants
   - 3 events
   - categories for every event
   - sample enrolments
   - sample results
   ============================================================ */

INSERT INTO Roles (RoleName)
VALUES
('Organiser'),
('Participant');
GO

INSERT INTO Users
(RoleID, FirstName, LastName, Email, PasswordHash, Phone)
VALUES
(1, 'Thabo', 'Mokoena', 'thabo@raceday.co.za', 'HASHED_PASSWORD_001', '0825550101'),
(1, 'Lerato', 'Ndlovu', 'lerato@raceday.co.za', 'HASHED_PASSWORD_002', '0825550102'),
(2, 'Sipho', 'Dlamini', 'sipho@example.com', 'HASHED_PASSWORD_003', '0825550103'),
(2, 'Amahle', 'Nkosi', 'amahle@example.com', 'HASHED_PASSWORD_004', '0825550104'),
(2, 'Kabelo', 'Maseko', 'kabelo@example.com', 'HASHED_PASSWORD_005', '0825550105'),
(2, 'Naledi', 'Molefe', 'naledi@example.com', 'HASHED_PASSWORD_006', '0825550106');
GO

INSERT INTO Organisers
(UserID, OrganisationName, ContactEmail)
VALUES
(1, 'Mpumalanga Road Runners', 'events@mprr.co.za'),
(2, 'Gauteng Athletics Events', 'info@gae.co.za');
GO

INSERT INTO Participants
(UserID, DateOfBirth)
VALUES
(3, '2001-06-15'),
(4, '1998-09-22'),
(5, '2004-02-11'),
(6, '1995-12-03');
GO

INSERT INTO Events
(OrganiserID, EventName, EventDescription, EventDate, StartTime, Venue, City, EntryFee, Capacity, Status)
VALUES
(1, 'Emalahleni City Run 2026',
 'A community road-running event for recreational and competitive runners.',
 '2026-10-18', '07:00', 'Municipal Sports Stadium', 'Emalahleni', 150.00, 1000, 'Open'),

(1, 'Highveld Trail Challenge 2026',
 'A trail-running event through scenic Highveld routes.',
 '2026-11-08', '06:30', 'Highveld Nature Reserve', 'Emalahleni', 220.00, 500, 'Open'),

(2, 'Johannesburg Spring Marathon 2026',
 'A major city road race featuring marathon, half-marathon and 10 km categories.',
 '2026-09-27', '06:00', 'Nasrec Expo Centre', 'Johannesburg', 300.00, 3000, 'Open');
GO

INSERT INTO Categories
(EventID, CategoryName, MinimumAge, MaximumAge, Gender, DistanceKM)
VALUES
(1, '10 KM Open', 16, NULL, 'Open', 10.00),
(1, '21 KM Open', 18, NULL, 'Open', 21.10),
(1, '5 KM Fun Run', 12, NULL, 'Open', 5.00),

(2, 'Trail 15 KM', 16, NULL, 'Open', 15.00),
(2, 'Trail 30 KM', 18, NULL, 'Open', 30.00),

(3, 'Marathon', 18, NULL, 'Open', 42.20),
(3, 'Half Marathon', 16, NULL, 'Open', 21.10),
(3, '10 KM Road Race', 14, NULL, 'Open', 10.00);
GO

INSERT INTO EventEnrolments
(EventID, CategoryID, ParticipantID, EnrolmentStatus, RaceNumber)
VALUES
(1, 1, 1, 'Confirmed', 101),
(1, 2, 2, 'Confirmed', 102),
(1, 3, 3, 'Confirmed', 103),
(2, 4, 4, 'Confirmed', 201),
(2, 5, 1, 'Confirmed', 202),
(3, 6, 2, 'Confirmed', 301),
(3, 7, 3, 'Confirmed', 302),
(3, 8, 4, 'Confirmed', 303);
GO

INSERT INTO Results
(EnrolmentID, FinishTime, FinishPosition, ResultStatus)
VALUES
(1, '00:48:21.000', 12, 'Finished'),
(2, '01:43:15.000', 8, 'Finished'),
(3, '00:29:44.000', 5, 'Finished'),
(4, '01:17:35.000', 4, 'Finished'),
(5, '02:41:10.000', 9, 'Finished'),
(6, '03:18:42.000', 15, 'Finished'),
(7, '01:39:20.000', 11, 'Finished'),
(8, '00:47:03.000', 6, 'Finished');
GO

/* =========================
   VALIDATION / DEMONSTRATION
   ========================= */
SELECT * FROM Roles;
SELECT * FROM Users;
SELECT * FROM Organisers;
SELECT * FROM Participants;
SELECT * FROM Events;
SELECT * FROM Categories;
SELECT * FROM EventEnrolments;
SELECT * FROM Results;
GO

/* Relationship validation query */
SELECT
    e.EventName,
    c.CategoryName,
    p.ParticipantID,
    u.FirstName + ' ' + u.LastName AS ParticipantName,
    ee.RaceNumber,
    r.FinishTime,
    r.FinishPosition
FROM EventEnrolments ee
INNER JOIN Events e ON ee.EventID = e.EventID
INNER JOIN Categories c ON ee.CategoryID = c.CategoryID
INNER JOIN Participants p ON ee.ParticipantID = p.ParticipantID
INNER JOIN Users u ON p.UserID = u.UserID
LEFT JOIN Results r ON ee.EnrolmentID = r.EnrolmentID
ORDER BY e.EventDate, ee.RaceNumber;
GO
