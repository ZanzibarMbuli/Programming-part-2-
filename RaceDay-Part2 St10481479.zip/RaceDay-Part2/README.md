# RaceDay – Part 2 API implementation starter

ASP.NET Core 8 minimal REST API based on the eight-entity RaceDay Part 1 database and endpoint plan. It includes JWT bearer authentication, hashed passwords, role policies, EF Core SQL Server mapping, Swagger, an initial unit-test project and GitHub Actions CI.

> **Academic integrity:** This project was AI-assisted. Review every file, make your own design decisions, test it in your environment, and disclose AI assistance in line with the PROG6212 POE instructions. This is not a guaranteed mark or a substitute for your own understanding and demonstration.

## Requirements
- .NET 8 SDK
- SQL Server / SQL Server Express / LocalDB
- Visual Studio 2022 or another .NET-capable editor

## Database setup
1. Open `docs/RaceDay_Database.sql` in SQL Server Management Studio.
2. Run it on a development instance. **Warning:** the supplied Part 1 script drops and recreates `RaceDayDB` if it already exists. Back up any database you need before running it.
3. Update `RaceDay.Api/appsettings.json` → `ConnectionStrings:RaceDay` for your SQL Server instance.
4. Change `Jwt:Key` to a private random secret of at least 32 characters. Do not commit production secrets. Use user secrets or environment variables for a real deployment.

## Run
From this directory:

```bash
dotnet restore RaceDay.sln
dotnet build RaceDay.sln
dotnet test RaceDay.sln
dotnet run --project RaceDay.Api
```

Open the Swagger URL printed by the app (usually `https://localhost:xxxx/swagger`). This API expects the SQL schema from Part 1 to be created first; it does not auto-create or migrate the database.

## Authentication walkthrough
1. Use `POST /api/auth/register` with `firstName`, `lastName`, `email`, `password`, and `dateOfBirth` in `yyyy-MM-dd` format. Public registration creates Participants only. This prevents a new user from granting themselves Organiser privileges.
2. Use `POST /api/auth/login` with `email` and `password`.
3. Copy `accessToken` from the response and click **Authorize** in Swagger; enter `Bearer <token>` if the Swagger dialog requires it.
4. Try protected endpoints. Organiser and Participant endpoints enforce role policies, and event edits verify ownership.

Example participant registration JSON:

```json
{
  "firstName": "Amina",
  "lastName": "Dlamini",
  "email": "amina.example@example.com",
  "password": "Use-a-unique-local-password-123!",
  "role": "Participant",
  "phone": "0710000000",
  "dateOfBirth": "2001-04-12",
  "organisationName": null
}
```

## Implemented route groups
- Authentication: register, login
- Profile: get and update current profile
- Events: list, details, create, update, delete
- Categories: list by event, details, create, update, delete
- Enrolments: create, list for event/participant, details, cancel
- Results: list by event, details, record and update
- Health: `/api/health`

## Validation and security controls
- Public registration is restricted to Participants; Organiser accounts must be provisioned by an administrator through an approved database/admin process.
- Email format and length, password minimum length/letter/digit requirements, and date-of-birth format/range are validated.
- Event fields, event capacity/fees/status, category age ranges/gender/distance, and result position/status use shared validation rules.
- Organiser-owned event/category/result operations verify ownership; participants cannot inspect another participant's enrolments unless they are the organiser of an event in those enrolments.
- Database uniqueness constraints protect email, event/category names, enrolments and race numbers. The API translates selected database conflicts into HTTP 409 responses.

These controls improve baseline security, but this is an academic demonstration, not a production-ready service. For production, add rate limiting, email verification, password reset, audit logging, centralised exception handling, secret storage, database migrations, and concurrency-safe capacity enforcement.

## Testing and CI
The test project now includes unit tests for email/password/date validation, event/category/result business rules, and entity defaults. These tests exercise shared validation logic but are **not a substitute for endpoint integration tests** against a test database. Before submission, also verify registration/login, unauthenticated access, Organiser-vs-Participant authorization, ownership, duplicate enrolments, capacity limits, and result creation through Swagger or automated integration tests.

Run locally:
```bash
dotnet restore RaceDay.sln
dotnet build RaceDay.sln --configuration Release
dotnet test RaceDay.sln --configuration Release --logger "console;verbosity=normal"
```

The GitHub Actions workflow builds and runs the test suite on pushes and pull requests. A green workflow must be produced by your own repository; do not claim success until the workflow has actually completed.

## Submission checklist
- [ ] Verify all endpoints and error cases against `docs/API_Endpoint_Plan.md`.
- [ ] Run the API locally against SQL Server and test it through Swagger.
- [ ] Add and run endpoint integration tests against a separate test database.
- [ ] Push meaningful commits reflecting your own work (do not fabricate commit history).
- [ ] Capture and insert a real successful GitHub Actions build screenshot.
- [ ] Record your own voice-over demo showing the running API, explaining code and tests; add the unlisted YouTube URL here.
- [ ] Review and disclose AI assistance according to the assignment instructions.

## AI-use disclosure example
“AI assistance was used to help scaffold and review parts of the API project. I reviewed and adapted the implementation, ran the tests, and take responsibility for the submitted work.” Only use this wording if it accurately describes what you did.
